"""
DNEVNIK MOS LIB

version 0.1 beta

Work on Closed API DNEVNIK МЭШ (MOS)
"""

from dnevniklib.marks import *
from dnevniklib.homeworks import *
from dnevniklib.school import *
from dnevniklib.user import *