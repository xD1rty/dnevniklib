"""
DNEVNIK MOS LIB

version 0.1 beta

Work on Closed API DNEVNIK МЭШ (MOS)
"""

from marks import *
from homeworks import *
from school import *
from user import *